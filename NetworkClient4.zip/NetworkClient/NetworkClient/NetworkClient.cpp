#include "NetworkClient.h"

//IP 130.240.40.7


NetworkClient::NetworkClient() {

}


NetworkClient::~NetworkClient() {

}